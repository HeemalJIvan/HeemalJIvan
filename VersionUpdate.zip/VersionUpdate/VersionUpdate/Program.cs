﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml;

namespace VersionUpdate
{
    class Program
    {

        public static int success { get; set; }
        public static int failed { get; set; }
        static void Main(string[] args)
        {
            success = 0;
            failed = 0;
            var VersionPath = ConfigurationManager.AppSettings["VersionPath"];
            string[] Patterns = new string[] { "*.xml", "*.wxi", "*.sln", "*.cs", "*.txt" };
            Console.WriteLine("What is the version you want to update?");
            string version = Console.ReadLine();
            Console.WriteLine("What is the new version?");
            string newVersion = Console.ReadLine();
            Console.WriteLine($"Are you so you want to update? {version} to {newVersion} (Y/N)");
            bool updatedVersion = Console.ReadLine().ToUpper() == "Y";

            for (int i = 0; i < Patterns.Length; i++)
            {
                string[] files = Directory.GetFiles(VersionPath, Patterns[i], SearchOption.AllDirectories);
                getFiles(files.ToList<string>(), updatedVersion, version, newVersion);
            }
            
            Console.WriteLine($"{success}-success");
            Console.WriteLine($"{failed}-Failed");
            Console.WriteLine("Press enter to exit.");
            Console.ReadLine();
        }

        public static void getFiles(List<string> getFiles, bool updatedVersion, string version, string newVersion)
        {
            if (updatedVersion)
            {
                if (!string.IsNullOrEmpty(version) && !string.IsNullOrEmpty(newVersion))
                {
                    foreach (var files in getFiles)
                    {
                        try
                        {
                            string fileContent = System.IO.File.ReadAllText(files);

                            if (fileContent.Contains(version))
                            {
                                fileContent = fileContent.Replace(version, newVersion);
                                System.IO.File.WriteAllText(files, fileContent);
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine($"{files}-Successful");
                                success++;
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                        }
                        catch (Exception e)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"{files}-Failed");
                            Console.WriteLine($"{e}");
                            Console.ForegroundColor = ConsoleColor.White;
                            failed++;
                            continue;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Please enter a valid version number!!!");
                }
            }
            else
            {
                Console.WriteLine("Update Cancelled");
            }
        }
    }
}

