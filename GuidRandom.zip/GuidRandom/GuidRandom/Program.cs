﻿using System;
using System.Xml;
using System.Configuration;
using System.IO;
using System.Collections.Generic;

namespace GuidRandom
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> lstPath = new List<string>();
            foreach (string item in ConfigurationManager.AppSettings)
            {
                if (item.Contains("Path"))
                {
                    lstPath.Add(ConfigurationManager.AppSettings[item]);
                }
            }
            Return(lstPath);
        }

        public static void Return(List<string> paths)
        {
            XmlDocument doc = new XmlDocument();
            foreach (string path in paths)
            {
                try
                {
                    doc.Load(path);
                    foreach (XmlNode node in doc.DocumentElement.SelectNodes("//*"))
                    {
                        if (node.HasChildNodes)
                        {
                            foreach (XmlNode xml in node.ChildNodes)
                            {
                                if (xml.InnerText.Length > 0)
                                {
                                    string[] innerText = xml.InnerText.Split('=');
                                    if (Guid.TryParse(innerText[1].Replace("\"", ""), out Guid count))
                                    {
                                        string newGuid = Guid.NewGuid().ToString("D").ToString().ToUpper();
                                        xml.InnerText = $"{innerText[0]}=\"{{{newGuid}}}\"";
                                    }
                                }
                            }
                        }
                    }
                    doc.Save(path);
                }
                catch (Exception)
                {
                    Console.WriteLine($"{path} File does not exist, ensure the correct path exist!!!");
                }
            }
        }
    }
}

