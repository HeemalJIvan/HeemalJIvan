﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] i = new string[] { "*.txt*" };
            FileManager somethingElse = new FileManager("Onetwo", "", "C:\\Users\\user-pc\\Desktop\\FileManager\\File", i, false, "C:\\Users\\user-pc\\Desktop\\FileManager\\Copied", false, " friday ", "yyyy-MM-dd HH_mm_ss", "Copy");
            somethingElse.RenameFunction();


        }
    }
}


public class FileManager
{

    public string SourceDirectory { get; set; }
    public string[] SearchPatterns { get; set; }
    public bool IncludeSubDirectories { get; set; }
    public string TargetDirectory { get; set; }
    public bool Overwrite { get; set; }
    public string AppendText { get; set; }
    public string DateTimeFormat { get; set; }
    public string Choice { get; set; }
    public string NewName { get; set; }
    public string FileName { get; set; }


    public FileManager(string fileName, string newName, string sourceDirectory, string[] searchPatterns, bool includeSubDirectories, string targetDirectory, bool overWrite, string appendText, string dateTimeFormat, string choice)
    {
        SourceDirectory = sourceDirectory;
        SearchPatterns = searchPatterns;
        IncludeSubDirectories = includeSubDirectories;
        TargetDirectory = targetDirectory;
        Overwrite = overWrite;
        AppendText = appendText;
        DateTimeFormat = dateTimeFormat;
        Choice = choice;
        NewName = newName;
        FileName = fileName;
    }

    public void Execute()
    {


        if (Choice == "Move".ToUpper())
        {
            ////Log("Retrieving source files ...");
            SearchOption searchOption = IncludeSubDirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            string[] files = GetFiles(SourceDirectory, SearchPatterns, searchOption);
            ////Log("{0} files retrieved.", files.Length);

            ////Log("Moving files ...");
            foreach (string file in files)
            {
                try
                {

                    string fileName = System.IO.Path.GetFileName(file);
                    string targetPath = System.IO.Path.Combine(TargetDirectory, fileName);


                    if (File.Exists(targetPath))
                    {
                        if (Overwrite)
                        {
                            //LogWarning("Overwrite set to true. Path: {0}", targetPath);
                            File.Copy(file, targetPath, true);
                            File.Delete(file);
                        }
                        else
                        {
                            //LogWarning("Overwrite set to false. Path {0}", targetPath);
                        }
                    }
                    else
                    {
                        File.Move(file, targetPath);
                    }
                }
                catch (Exception e)
                {
                    //LogError(e.Message, e);
                }
            }
            ////Log("Files moved.");

        }
        else if (Choice == "Rename".ToUpper())
        {

            ////Log("Files Renamed");
        }
        else if (Choice.ToLower() == "datestamp")
        {
            ////Log("Collecting files to process ...");
            SearchOption option = IncludeSubDirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            string[] files = Directory.GetFiles(SourceDirectory, SearchPatterns.ToString(), option);
            ////Log("{0} files collected.", files.Length);


            ////Log("Stamping files ...");
            foreach (string file in files)
            {
                try
                {
                    ////Log("Stamping file ...");
                    //LogHint("Source File: {0}", file);

                    string directoryName = System.IO.Path.GetDirectoryName(file);
                    string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(file);
                    string extension = System.IO.Path.GetExtension(file);
                    string timestamp = DateTime.Now.ToString(DateTimeFormat);
                    string targetFileNameWithoutExtension = fileNameWithoutExtension + AppendText + timestamp;
                    string targetFileName = targetFileNameWithoutExtension + extension;
                    string targetFile = System.IO.Path.Combine(TargetDirectory, targetFileName);

                    //LogHint("Target File: {0}", targetFile);

                    File.Move(file, targetFile);


                    ////Log("File stamped.");
                    ////Log("");
                }
                catch (Exception e)
                {
                    //LogError("An error occurred while stamping the file: {0}", e, e.Message);
                }
            }
            ////Log("All files stamped.");
        }
        //return FluidProcessResponse.Pass();

    }
    private string[] GetFiles(string path, string[] searchPatterns, SearchOption searchOption)
    {

        List<string> list = new List<string>();


        foreach (string searchPattern in searchPatterns)
        {
            string[] files = Directory.GetFiles(path, searchPattern, searchOption);
            list.AddRange(files);
        }

        return list.ToArray();
    }
    public void RenameFunction()
    {
        if (Choice.ToLower() == "datestamp")
        {
            ////Log("Collecting files to process ...");
            SearchOption option = IncludeSubDirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            string[] files = Directory.GetFiles(SourceDirectory, SearchPatterns.ToString(), option);
            ////Log("{0} files collected.", files.Length);


            ////Log("Stamping files ...");
            foreach (string file in files)
            {
                try
                {
                    ////Log("Stamping file ...");
                    //LogHint("Source File: {0}", file);

                    string directoryName = System.IO.Path.GetDirectoryName(file);
                    string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(file);
                    string extension = System.IO.Path.GetExtension(file);
                    string timestamp = DateTime.Now.ToString(DateTimeFormat);
                    string targetFileNameWithoutExtension = fileNameWithoutExtension + AppendText + timestamp;
                    string targetFileName = targetFileNameWithoutExtension + extension;
                    string targetFile = System.IO.Path.Combine(TargetDirectory, targetFileName);

                    //LogHint("Target File: {0}", targetFile);

                    File.Move(file, targetFile);


                    ////Log("File stamped.");
                    ////Log("");
                }
                catch (Exception e)
                {
                    //LogError("An error occurred while stamping the file: {0}", e, e.Message);
                }
            }
            ////Log("All files stamped.");
        }


        //if (Choice.ToLower() == "copy")
        //{

        //    //LogInfo("Retrieving source files ...");
        //    SearchOption searchOption = IncludeSubDirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
        //    string[] files = GetFiles(SourceDirectory, SearchPatterns, searchOption);
        //   // LogInfo("{0} files retrieved.", files.Length);

        //   // LogInfo("Coping files ...");
        //    foreach (string file in files)
        //    {
        //        try
        //        {
        //            string directoryName = System.IO.Path.GetDirectoryName(file);
        //            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(file);
        //            string extension = System.IO.Path.GetExtension(file);
        //            string timestamp = DateTime.Now.ToString(DateTimeFormat);
        //            string targetFileNameWithoutExtension = fileNameWithoutExtension + AppendText + timestamp;
        //            string targetFileName = targetFileNameWithoutExtension + extension;
        //            string targetFile = System.IO.Path.Combine(TargetDirectory, targetFileName);
        //            string targetPath = System.IO.Path.Combine(TargetDirectory,  targetFile);


        //            if (File.Exists(targetPath))
        //            {
        //                if (Overwrite)
        //                {
        //                   // LogWarning("Overwrite set to true. Path: {0}", targetPath);
        //                    File.Copy(file, targetPath, true);
        //                }
        //                else
        //                {
        //                   // LogWarning("Overwrite set to false. Path {0}", targetPath);
        //                }
        //            }
        //            else
        //            {
        //                File.Copy(file, targetPath);
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            //LogError(e.Message, e);
        //        }
        //    }
        //    //LogInfo("Files moved.");

        //}

    }
}


